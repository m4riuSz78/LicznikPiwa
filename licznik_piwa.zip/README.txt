LICZNIK PIWA 🍺 - INSTRUKCJA URUCHOMIENIA (2 minuty)

1. Wejdź na: https://vercel.com/import
2. Wybierz: "Import from Git" ➜ kliknij "Upload"
3. Przeciągnij i upuść ten ZIP
4. Poczekaj aż się zbuduje (1-2 min)
5. Gotowe! Otwórz link z Vercela i kliknij "Dodaj do ekranu głównego" na telefonie

To wszystko! 🍻
